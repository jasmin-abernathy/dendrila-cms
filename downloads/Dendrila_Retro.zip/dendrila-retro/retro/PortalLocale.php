<?php
declare(strict_types=1);

namespace Dendrila\Cms\Oldweb;

if (!defined('DENDRILA_RETRO_ENTRY')) {
    http_response_code(404);
    return;
}


use Closure;
use InvalidArgumentException;

final class PortalLocale
{
    public const DEFAULT = 'fr';
    public const LANGUAGES = ['fr' => 'Français', 'en' => 'English'];

    public static function selected(mixed $value): ?string
    {
        return is_string($value) && isset(self::LANGUAGES[$value]) ? $value : null;
    }

    public static function required(mixed $value): string
    {
        return self::selected($value) ?? throw new InvalidArgumentException('Choisis le français ou l’anglais.');
    }

    public static function text(string $language, string $message, string ...$arguments): string
    {
        $text = $language === 'en' ? (self::ENGLISH[$message] ?? $message) : $message;
        return $arguments === [] ? $text : sprintf($text, ...$arguments);
    }

    public static function escape(string $language): Closure
    {
        return static fn (string $message, string ...$arguments): string => htmlspecialchars(
            self::text($language, $message, ...$arguments), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'
        );
    }

    private const ENGLISH = [
        'Langue d’installation' => 'Setup language',
        'Installer Dendrila Retro' => 'Install Dendrila Retro',
        'Tant que le site n’est pas installé, la première personne qui termine ce formulaire devient administratrice. Termine maintenant ou protège temporairement le site depuis ton hébergement.' => 'Until the site is installed, the first person to complete this form becomes the administrator. Finish setup now or use your hosting control panel to temporarily protect the site.',
        'Le mode protégé est actif. Saisis la clé correspondant au fichier déposé dans ton dossier privé.' => 'Protected setup is enabled. Enter the key for the file you uploaded to your private folder.',
        'Nom du site' => 'Site name',
        'Sous-titre (facultatif)' => 'Tagline (optional)',
        'Thème' => 'Theme',
        'Aperçu interactif' => 'Interactive preview',
        'Voir %s' => 'Preview %s',
        'Les liens ouvrent l’aperçu sans effacer le formulaire. Choisis ensuite le même thème dans la liste pour l’installer.' => 'The links open a preview and keep your form entries. To install that theme, also select it from the list.',
        'Aperçu à largeur fixe, défilable horizontalement' => 'Fixed-width preview with horizontal scrolling',
        'Aperçu interactif du thème' => 'Interactive theme preview',
        'Ouvrir cet aperçu en taille réelle' => 'Open this preview at full size',
        'Clé d’installation (fichier LIRE-MOI.txt)' => 'Installation key (LIRE-MOI.txt file)',
        'Clé d’installation' => 'Installation key',
        'Identifiant administrateur' => 'Administrator username',
        'De 3 à 32 caractères. Lettres sans accent, chiffres, points, tirets et tirets bas.' => 'Use 3 to 32 characters: unaccented letters, numbers, periods, hyphens or underscores.',
        'Mot de passe' => 'Password',
        'Au moins 14 caractères, 72 octets maximum.' => 'At least 14 characters and no more than 72 bytes.',
        'Confirmer le mot de passe' => 'Confirm password',
        'Créer ta clé d’installation' => 'Create your installation key',
        'Installation protégée.' => 'Protected setup.',
        'Choisis une clé unique et garde-la à portée de main. Tu en auras besoin à l’étape suivante.' => 'Choose a unique key and keep it handy. You will need it in the next step.',
        'Clé d’installation (24 caractères minimum)' => 'Installation key (at least 24 characters)',
        'Télécharger le fichier de clé' => 'Download the key file',
        'Téléverse le fichier dans le dossier privé de ton hébergement, hors de toutes les racines web. Conserve le nom indiqué par le téléchargement.' => 'Upload the file to a private folder on your hosting account, outside all web roots. Keep the filename shown in the download.',
        'J’ai téléversé le fichier, continuer' => 'I have uploaded the file. Continue',
        'Connexion à Dendrila Retro' => 'Sign in to Dendrila Retro',
        'Retour au site' => 'Back to the site',
        'Se connecter' => 'Sign in',
        'Se déconnecter' => 'Sign out',
        'Apparence du portail Oldweb' => 'Oldweb portal appearance',
        'Page publiée' => 'Published site',
        'Voir le brouillon' => 'Preview the draft',
        'Langue' => 'Language',
        'Appliquer la langue' => 'Apply language',
        'Cette langue s’applique au back-office et aux textes de démonstration du site.' => 'This language applies to the back office and the site’s demo content.',
        'Utilise des couleurs' => 'Use colours in the form',
        'Les polices sont choisies parmi celles disponibles sur l’appareil du visiteur. Les fichiers GIF, PNG et JPEG sont limités à 1 Mio et 1 600 px par côté. Renseigne un texte de remplacement si l’image donne une information.' => 'Fonts depend on what is available on the visitor’s device. GIF, PNG and JPEG files are limited to 1 MiB and 1,600 px per side. Add alternative text for images that convey information.',
        'Thème du portail' => 'Portal theme',
        'Appliquer les couleurs et les bordures d’origine du thème sélectionné' => 'Apply the selected theme’s original colours and borders',
        'Fond' => 'Background',
        'Texte' => 'Text',
        'Bordure' => 'Border',
        'Police générale' => 'Site font',
        'Police' => 'Font',
        'Type de fond' => 'Background type',
        'Fond du thème' => 'Theme background',
        'Couleur unie' => 'Solid colour',
        'Image répétée' => 'Tiled image',
        'Le motif est répété horizontalement et verticalement à sa taille d’origine. La couleur reste disponible en mode uni.' => 'The pattern repeats horizontally and vertically at its original size. You can still use the colour with the solid background option.',
        'Voir l’image actuelle' => 'View the current image',
        'Retirer le fichier de fond' => 'Remove the background file',
        'Retirer l’image' => 'Remove the image',
        'Image de fond' => 'Background image',
        'Nouvelle image' => 'New image',
        'Texte de remplacement' => 'Alternative text',
        'Enregistrer le brouillon' => 'Save draft',
        'Publier' => 'Publish',
        'Rétablir la version précédente' => 'Restore previous version',
        'Fond du site' => 'Site background',
        'Grand bandeau' => 'Top banner',
        'Enseigne' => 'Site title',
        'Boutons du menu' => 'Menu buttons',
        'Ouverture' => 'Introduction',
        'À l’antenne' => 'On air',
        'Agenda' => 'Schedule',
        'Archives' => 'Archives',
        'Colonne latérale' => 'Sidebar',
        'Trait simple' => 'Solid',
        'Double trait' => 'Double',
        'En relief' => 'Ridge',
        'En creux' => 'Inset',
        'Saillant' => 'Outset',
        'Tirets' => 'Dashed',
        'Sans bordure' => 'No border',
        'Police du thème' => 'Theme font',
        'Aperçu du brouillon' => 'Draft preview',
        'Retour aux réglages' => 'Back to settings',
        'Accueil' => 'Home',
        'Nous écrire' => 'Write to us',
        'Sur le site' => 'On this site',
        'L’émission du mois' => 'This month’s show',
        'Les prochaines dates' => 'Upcoming events',
        'Les anciennes bandes' => 'The old tapes',
        'Courrier' => 'Mail',
        'SUR' => 'ON',
        'LES ONDES' => 'THE AIR',
        'Voir l’heure de la diffusion' => 'Check the broadcast time',
        'Agenda du club' => 'Club calendar',
        'BANDES' => 'TAPE',
        'ARCHIVES' => 'ARCHIVE',
        'Haut de page' => 'Back to top',
        'Afficher les GIF' => 'Show GIFs',
        'Masquer les GIF' => 'Hide GIFs',
        'Aller au contenu' => 'Skip to content',
        'Crédits' => 'Credits',
        'Journal' => 'News',
        'Dossiers' => 'Files',
        'Le club' => 'The club',
        'Journal du club' => 'Club news',
        'Voir la prochaine soirée' => 'See the next meetup',
        'À la une' => 'Featured',
        'Voir le programme' => 'See the programme',
        'Soirée arcade' => 'Arcade night',
        'À l’affiche' => 'What’s on',
        'Le défi du mois' => 'This month’s challenge',
        'Crédits des illustrations (CC0)' => 'Artwork credits (CC0)',
        'Novembre' => 'November',
        'Bienvenue' => 'Welcome',
        'Vers de nouveaux horizons' => 'Off to new horizons',
        'Bonne exploration, et à bientôt sur le réseau !' => 'Happy exploring, and see you on the web!',
        'Le ciel de novembre' => 'The November sky',
        'Quoi de neuf au club ?' => 'What’s new at the club?',
        'Site de démonstration' => 'Demo site',
        'Retour en haut' => 'Back to top',
        'Fond :' => 'Background:',
        'adaptation GIF' => 'GIF adaptation',
        'Ouvre cette page avec une adresse qui commence par https://.' => 'Open this page using an address that starts with https://.',
        'Le formulaire a expiré. Recharge la page puis réessaie.' => 'This form has expired. Reload the page and try again.',
        'Ce portail est déjà installé.' => 'This portal is already installed.',
        'Ce portail vient d’être installé.' => 'This portal has just been installed.',
        'Ouvrir la connexion' => 'Open the sign-in page',
        'Identifiant ou mot de passe incorrect.' => 'Incorrect username or password.',
        'Action d’installation inconnue.' => 'Unknown setup action.',
        'Le mode protégé exige un fichier de clé valide dans le dossier privé.' => 'Protected setup requires a valid key file in the private folder.',
        'L’identifiant doit faire de 3 à 32 caractères, avec lettres sans accent, chiffres, points, tirets ou tirets bas.' => 'Use 3 to 32 characters for the username: unaccented letters, numbers, periods, hyphens or underscores.',
        'Choisis un mot de passe d’au moins 14 caractères et de 72 octets au maximum.' => 'Choose a password of at least 14 characters and no more than 72 bytes.',
        'Les deux mots de passe doivent être identiques.' => 'The passwords must match.',
        'La clé d’installation ne correspond pas au kit ou au fichier de clé.' => 'The installation key does not match the kit or key file.',
        'Trop de tentatives. Réessaie dans quelques minutes.' => 'Too many attempts. Try again in a few minutes.',
        'Choisis une clé de 24 à 128 caractères, avec des lettres sans accent, des chiffres ou des symboles et sans espace au début ou à la fin.' => 'Choose a 24- to 128-character key using unaccented letters, numbers or symbols, with no leading or trailing spaces.',
        'La session du formulaire a expiré. Retourne à la page d’apparence et recharge-la.' => 'The form session has expired. Go back to the appearance page and reload it.',
        'Le formulaire est incomplet.' => 'The form is incomplete.',
        'Ce site est déjà installé.' => 'This site is already installed.',
        'Installe d’abord Dendrila Retro.' => 'Install Dendrila Retro first.',
        'Une autre modification a été enregistrée. Vérifie la version actuelle avant de réessayer.' => 'Someone saved another change. Review the current version before trying again.',
        'Dendrila Retro est installé.' => 'Dendrila Retro is installed.',
        'Brouillon enregistré.' => 'Draft saved.',
        'Apparence publiée.' => 'Appearance published.',
        'Version précédente rétablie.' => 'Previous version restored.',
        'Langue mise à jour.' => 'Language updated.',
        'Choisis le français ou l’anglais.' => 'Choose French or English.',
        'Portail momentanément indisponible.' => 'The portal is temporarily unavailable.',
        'Zone de téléversement inconnue.' => 'Unknown upload area.',
        'Le fichier doit être une image de 1 Mio maximum.' => 'The file must be an image no larger than 1 MiB.',
        'Le fichier dépasse 1 Mio.' => 'The file is larger than 1 MiB.',
        'Choisis un GIF, PNG ou JPEG valide de 1 600 px maximum par côté.' => 'Choose a valid GIF, PNG or JPEG no larger than 1,600 px per side.',
        'Action indisponible.' => 'This action is unavailable.',
        'Indique un nom de 1 à 55 caractères et un sous-titre de 100 caractères au plus.' => 'Enter a name of 1 to 55 characters and a tagline of up to 100 characters.',
        'L’espace des images Oldweb est plein.' => 'The Oldweb image storage is full.',
        'La zone sélectionnée n’existe pas.' => 'The selected area does not exist.',
        'Réglages incomplets pour « %s ».' => 'The settings for “%s” are incomplete.',
        'Bordure inconnue pour « %s ».' => 'Unknown border for “%s”.',
        'Police inconnue pour « %s ».' => 'Unknown font for “%s”.',
        'Augmente le contraste du texte pour « %s ».' => 'Increase the text contrast for “%s”.',
        'Cette zone ne peut pas accueillir d’image.' => 'This area cannot display an image.',
        'Le texte de remplacement doit faire au plus 200 caractères.' => 'Alternative text must be 200 characters or fewer.',
        'Choisis un type de fond valide.' => 'Choose a valid background type.',
        'Choisis une image de fond.' => 'Choose a background image.',
        'Indique une couleur au format #RRGGBB.' => 'Enter a colour in #RRGGBB format.',
        'Sélectionne un thème installé.' => 'Select an installed theme.',
        'La configuration privée du kit est invalide.' => 'The kit’s private configuration is invalid.',
        'Dendrila Retro ne trouve pas de dossier privé hors du dossier web. Vérifie le guide de ton hébergement.' => 'Dendrila Retro could not find a private folder outside the web root. Check your hosting guide.',
        'Le dossier privé de Dendrila Retro doit être accessible en écriture et réservé à ton compte.' => 'The Dendrila Retro private folder must be writable and accessible only to your account.',
        'Dendrila Retro ne peut pas lire son état privé.' => 'Dendrila Retro cannot read its private settings.',
        'Dendrila Retro ne peut pas ouvrir de session sur cet hébergement.' => 'Dendrila Retro cannot start a session on this host.',
        'Le compte de ce portail doit être restauré depuis une sauvegarde.' => 'The portal account must be restored from a backup.',
        'Recharge la page pour te connecter au portail.' => 'Reload the page to sign in to the portal.',
        'Dendrila Retro ne parvient pas à créer son dossier privé.' => 'Dendrila Retro cannot create its private folder.',
        'Le portail ne peut pas enregistrer les tentatives de connexion.' => 'The portal cannot record sign-in attempts.',
        'Le portail ne peut pas contrôler les tentatives de connexion.' => 'The portal cannot check sign-in attempts.',
        'Dans cPanel, sélectionne PHP 8.4 ou une version plus récente pour ce domaine.' => 'Select PHP 8.4 or later for this domain in cPanel.',
        'Dans cPanel, active l’extension PHP %s pour ce domaine.' => 'Enable the %s PHP extension for this domain in cPanel.',
        'Le fichier de configuration du kit doit être un fichier ordinaire.' => 'The kit configuration must be a regular file.',
    ];
}
