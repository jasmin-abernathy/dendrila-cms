<?php

if (!defined('DENDRILA_RETRO_ENTRY')) {
    http_response_code(404);
    return;
}
return json_decode(<<<'RETRO_JSON'
{
  "name": "BORNE 02",
  "tagline": "Arcade club",
  "banner": "ARCADE CLUB",
  "status": "15.11",
  "frequency": "MONTHLY CHALLENGE",
  "introTitle": "Orbitale",
  "introText": "The last spaceship has to make it through the asteroid belt. On Friday, we play for the high score.",
  "newsTitle": "Pixel stroll",
  "newsText": "Jumps, coins and hidden passages.",
  "agendaFirst": "Friday · 8 pm",
  "agendaSecond": "Tournament, free play and a game swap.",
  "archiveTitle": "The basement",
  "archiveText": "A map to find your way around the dungeon.",
  "focusTitle": "The club",
  "focusText": "Bring a game to share. The arcade is open to everyone.",
  "contact": "Meetups to play games together.",
  "year": "2002"
}
RETRO_JSON, true, 32, JSON_THROW_ON_ERROR);
