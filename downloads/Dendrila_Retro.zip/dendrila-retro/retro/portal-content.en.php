<?php

if (!defined('DENDRILA_RETRO_ENTRY')) {
    http_response_code(404);
    return;
}
return json_decode(<<<'RETRO_JSON'
{
  "name": "CANAL 57",
  "tagline": "The night owls’ portal | Metz | Since 2000",
  "banner": "FRIDAY 8 PM / FREE ENTRY",
  "status": "LAST UPDATED — 13 NOV 2000",
  "frequency": "[ NIGHT SHIFT 03 / 11 ]",
  "introTitle": "The city after the last train",
  "introText": "Field reports, sound recordings and Friday outings.",
  "newsTitle": "A night on the platform",
  "newsText": "The sound club spent a night at the station, recording the last departure announcements and the first coffee run.",
  "agendaFirst": "Friday, 8 pm — Broadcast at the Salle du Faubourg.",
  "agendaSecond": "Saturday, 10 am — Photo walk, starting outside the station.",
  "archiveTitle": "On the last cassette",
  "archiveText": "October 2000. Hammers in the workshop, the metal gate and the 6:12 bus.",
  "focusTitle": "This week",
  "focusText": "A station special, from the last train to the first coffee.",
  "contact": "Drop off your tapes and ideas at the Salle du Faubourg from 7 pm on Friday.",
  "year": "2000"
}
RETRO_JSON, true, 32, JSON_THROW_ON_ERROR);
