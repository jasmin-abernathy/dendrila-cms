<?php
declare(strict_types=1);

if (!defined('DENDRILA_RETRO_ENTRY')) {
    http_response_code(404);
    return;
}


$escape = static fn (string $value): string => htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
?>
<!doctype html>
<html lang="<?= $language ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $tr('Créer ta clé d’installation') ?> — Dendrila Retro</title>
<style type="text/css">
body { color:#111; background:#e1e7ff; font:100%/1.5 Verdana,sans-serif; }
#page { margin:1em auto; padding:1em; max-width:44em; background:#fff; border:2px solid #2455e5; }
label { display:block; margin-top:.8em; }
input { box-sizing:border-box; font:inherit; max-width:95%; min-height:44px; }
a { line-height:2.75; color:#16246b; }
a:focus,input:focus { outline:2px solid #9f3600; }
.error { color:#8b1800; }
code { font-size:.85em; }

</style>
</head>
<body>
<main id="page">
<?php require __DIR__ . '/portal-language.php'; ?>
<h1><?= $tr('Créer ta clé d’installation') ?></h1>
<p><strong><?= $tr('Installation protégée.') ?></strong> <?= $tr('Choisis une clé unique et garde-la à portée de main. Tu en auras besoin à l’étape suivante.') ?></p>
<?php if ($error !== ''): ?><p class="error" role="alert"><strong><?= $escape($error) ?></strong></p><?php endif ?>
<form method="post" action="oldweb-editor.php">
<div>
<input type="hidden" name="csrf" value="<?= $escape($csrf) ?>">
<input type="hidden" name="lang" value="<?= $language ?>">
<input type="hidden" name="action" value="download-key">
<label for="activation"><?= $tr('Clé d’installation (24 caractères minimum)') ?></label>
<input id="activation" type="password" name="activation" size="38" maxlength="128">
<p><input type="submit" value="<?= $tr('Télécharger le fichier de clé') ?>"></p>
</div>
</form>
<p><?= $tr('Téléverse le fichier dans le dossier privé de ton hébergement, hors de toutes les racines web. Conserve le nom indiqué par le téléchargement.') ?></p>
<p><a href="oldweb-editor.php?lang=<?= $language ?>"><?= $tr('J’ai téléversé le fichier, continuer') ?></a></p>
</main>
</body>
</html>
