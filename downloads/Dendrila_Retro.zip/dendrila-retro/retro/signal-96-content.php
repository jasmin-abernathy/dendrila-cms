<?php

if (!defined('DENDRILA_RETRO_ENTRY')) {
    http_response_code(404);
    return;
}
return json_decode(<<<'RETRO_JSON'
{
  "name": "Signal 96",
  "tagline": "LE CLUB DES CURIEUX",
  "banner": "Réseau des amateurs",
  "status": "Dernier changement : 17/11/1996",
  "frequency": "Édition n° 04",
  "introTitle": "Bienvenue sur notre petit coin du Web !",
  "introText": "Signal 96 est un lieu de rencontre pour les passionnés de sciences, de bricolage et d'informatique. Ici, pas besoin d'être spécialiste : il suffit d'avoir envie de comprendre et de partager ses découvertes.\n\nRetrouve nos comptes rendus, nos projets et les rendez-vous du club. Ce site grandit au fil de nos expériences et de vos contributions.",
  "newsTitle": "Exploration",
  "newsText": "Notre carte du ciel : repérer les constellations d'hiver et observer Jupiter avec une petite lunette.",
  "agendaFirst": "Vendredi, 22 h : observation au belvédère.",
  "agendaSecond": "Samedi, 21 h : atelier radio.",
  "archiveTitle": "Dossiers",
  "archiveText": "Les signaux mystérieux, les carnets de terrain et les montages électroniques des membres.",
  "focusTitle": "Le club",
  "focusText": "Un groupe d'amateurs qui se retrouve pour observer, fabriquer et échanger.",
  "contact": "Une question ou une découverte ? Apporte ton carnet lors de la prochaine rencontre. Toutes les contributions sont les bienvenues.",
  "year": "1996"
}
RETRO_JSON, true, 32, JSON_THROW_ON_ERROR);
