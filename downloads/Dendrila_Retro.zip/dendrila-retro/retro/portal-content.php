<?php

if (!defined('DENDRILA_RETRO_ENTRY')) {
    http_response_code(404);
    return;
}
return json_decode(<<<'RETRO_JSON'
{
  "name": "CANAL 57",
  "tagline": "Le portail des noctambules | Metz | Depuis 2000",
  "banner": "VENDREDI 20 H / ENTRÉE LIBRE",
  "status": "DERNIÈRE MISE À JOUR — 13 NOV. 2000",
  "frequency": "[ NOCTURNE 03 / 11 ]",
  "introTitle": "La ville après le dernier train",
  "introText": "Reportages, prises de son et sorties du vendredi.",
  "newsTitle": "Une nuit sur le quai",
  "newsText": "Le club son a passé une nuit à la gare. Au programme, les annonces du dernier départ et la tournée des premiers cafés.",
  "agendaFirst": "Vendredi, 20 h — Diffusion à la salle du Faubourg.",
  "agendaSecond": "Samedi, 10 h — Balade photo, départ devant la gare.",
  "archiveTitle": "Sur la cassette précédente",
  "archiveText": "Octobre 2000. Les marteaux de l’atelier, la grille métallique et le bus de 6 h 12.",
  "focusTitle": "Cette semaine",
  "focusText": "Émission spéciale gare. Du dernier train au premier café.",
  "contact": "Déposez vos cassettes et vos idées le vendredi à la salle du Faubourg à partir de 19 h.",
  "year": "2000"
}
RETRO_JSON, true, 32, JSON_THROW_ON_ERROR);
