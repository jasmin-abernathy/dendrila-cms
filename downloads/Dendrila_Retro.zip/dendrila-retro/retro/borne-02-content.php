<?php

if (!defined('DENDRILA_RETRO_ENTRY')) {
    http_response_code(404);
    return;
}
return json_decode(<<<'RETRO_JSON'
{
  "name": "BORNE 02",
  "tagline": "Club d’arcade",
  "banner": "CLUB D’ARCADE",
  "status": "15.11",
  "frequency": "DÉFI DU MOIS",
  "introTitle": "Orbitale",
  "introText": "Le dernier vaisseau doit franchir la ceinture d’astéroïdes. Vendredi, on joue pour le meilleur score.",
  "newsTitle": "Balade pixel",
  "newsText": "Des sauts, des pièces et des passages cachés.",
  "agendaFirst": "Vendredi · 20 h",
  "agendaSecond": "Tournoi, parties libres et échange de jeux.",
  "archiveTitle": "Le sous-sol",
  "archiveText": "Une carte pour se retrouver dans le donjon.",
  "focusTitle": "Le club",
  "focusText": "Viens avec un jeu à faire découvrir. La borne est ouverte à tout le monde.",
  "contact": "Les rendez-vous pour jouer ensemble.",
  "year": "2002"
}
RETRO_JSON, true, 32, JSON_THROW_ON_ERROR);
