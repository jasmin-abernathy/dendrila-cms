<?php
declare(strict_types=1);
define('DENDRILA_RETRO_ENTRY', true);
$editor = false;
require __DIR__ . '/retro/bootstrap.php';
