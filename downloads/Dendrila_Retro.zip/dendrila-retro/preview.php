<?php
declare(strict_types=1);
define('DENDRILA_RETRO_ENTRY', true);
require __DIR__ . '/retro/standalone-preview.php';
